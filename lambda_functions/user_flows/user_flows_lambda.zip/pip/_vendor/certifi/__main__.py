from pip._vendor.certifi import where
print(where())
